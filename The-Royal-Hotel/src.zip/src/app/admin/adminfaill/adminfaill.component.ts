import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminfaill',
  templateUrl: './adminfaill.component.html',
  styleUrls: ['./adminfaill.component.scss']
})
export class AdminfaillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
