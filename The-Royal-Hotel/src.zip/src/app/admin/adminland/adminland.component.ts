import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminland',
  templateUrl: './adminland.component.html',
  styleUrls: ['./adminland.component.scss']
})
export class AdminlandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
