import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-hoteldetail',
  templateUrl: './hoteldetail.component.html',
  styleUrls: ['./hoteldetail.component.scss']
})
export class HoteldetailComponent implements OnInit {
  regitrationForm!:FormGroup;


  constructor(private fb:FormBuilder, private dataservice : DataService) { }

  ngOnInit(): void {
    this.regitrationForm = this.fb.group({
      userName:['',[Validators.required,Validators.maxLength(40)]],
      hotelName:['',[Validators.required,]],
      hotelAddress:['',[Validators.required,]],
      hotelMobile:['',[Validators.required,Validators.maxLength(10),Validators.pattern('^[0-9]{10}')]],
      hotelMenu:['',[Validators.required]],
      roomAvailable:['',Validators.required],
      owenrCheck:['',[Validators.requiredTrue]],
      userPass:['',[Validators.required, Validators.maxLength(8)]],

    });
   
  }
  postHoteldata(data:any){
    // console.log(data);
    //post hotel data
    this.dataservice.postHotelCall(data).subscribe((res)=>{
      console.log(res);

  })}

}
