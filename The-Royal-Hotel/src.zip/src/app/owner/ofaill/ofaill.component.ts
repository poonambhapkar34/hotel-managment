import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ofaill',
  templateUrl: './ofaill.component.html',
  styleUrls: ['./ofaill.component.scss']
})
export class OfaillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
