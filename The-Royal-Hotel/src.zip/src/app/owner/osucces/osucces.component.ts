import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-osucces',
  templateUrl: './osucces.component.html',
  styleUrls: ['./osucces.component.scss']
})
export class OsuccesComponent implements OnInit {
  apidata: any;
  flag= false;

  constructor( private dataservice : DataService) { }

  ngOnInit(): void {
    this.dataservice.getHotelCall().subscribe((data)=>{
      this.apidata=data
      console.log(data);
      })
      
      this.flag=true

  }
  td(d:any){
    console.log(d);
    console.log(d.value);
    
    
  }

//deletApi
deletData(id:any){
  this.dataservice.deletHotelCall(id).subscribe((data)=>{
   this.apidata.data
   console.log(data);
   
  })
   }


   getData(){
     this.dataservice.getHotelCall().subscribe((data)=>{
       this.apidata.data
       console.log(data);
       
     })
   }
}
