import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userland',
  templateUrl: './userland.component.html',
  styleUrls: ['./userland.component.scss']
})
export class UserlandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
