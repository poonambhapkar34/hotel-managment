import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usersucces',
  templateUrl: './usersucces.component.html',
  styleUrls: ['./usersucces.component.scss']
})
export class UsersuccesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
